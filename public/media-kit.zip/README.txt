Gold&Silver Media Kit (placeholder)
Generated: 2026-01-07

Contents:
- brand/ : logo placeholders
- charts/ : sample chart placeholders
- guidelines/ : simple usage notes

Replace the placeholders with your final assets.
